package com.example.a1a1a1.quickgeneric;
import java.util.*;
/**
 * Created by 1a1a1 on 2016-11-12.
 */
public class generic<I,S>{
    List<I> array_integer=new ArrayList<I>(10);
    List<S> array_string=new ArrayList<S>(10);


}
